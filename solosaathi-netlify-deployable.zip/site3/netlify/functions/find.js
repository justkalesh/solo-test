import { getStore } from "@netlify/blobs";
import { normalizeWhatsApp } from "../../shared/otp.js";

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (req.method !== "GET") return new Response("Method not allowed", { status: 405, headers });

  const url = new URL(req.url);
  const whatsapp = normalizeWhatsApp(url.searchParams.get("whatsapp"));
  if (!/^\d{10}$/.test(whatsapp)) {
    return new Response(JSON.stringify({ error: "Provide a valid 10-digit WhatsApp number" }), { status: 400, headers });
  }

  const store = getStore("solosaathi");
  // bymobile: keys are namespaced by date, so list by prefix to find every
  // night this number has a registration under, not just the latest.
  const { blobs } = await store.list({ prefix: `bymobile:${whatsapp}:` });
  const ids = await Promise.all(blobs.map((b) => store.get(b.key)));
  const records = await Promise.all(
    ids.filter(Boolean).map((id) => store.get(`registration:${id}`, { type: "json" }))
  );

  const results = records
    .filter(Boolean)
    .sort((a, b) => new Date(b.registeredAt) - new Date(a.registeredAt));

  return new Response(JSON.stringify(results), { status: 200, headers });
};
