import { getStore } from "@netlify/blobs";

const SEED_VENUES = {
  Ahmedabad: [
    { name: "United Way Garba Grounds", lat: 23.0395, lng: 72.5661 },
    { name: "Rajpath Club", lat: 23.0303, lng: 72.5108 },
    { name: "GMDC Ground", lat: 23.0469, lng: 72.5316 },
  ],
  Surat: [
    { name: "VR Surat Grounds", lat: 21.1959, lng: 72.7933 },
    { name: "Sarthana Ground", lat: 21.228, lng: 72.8619 },
  ],
  Vadodara: [
    { name: "Akota Stadium Grounds", lat: 22.2967, lng: 73.1631 },
    { name: "Sursagar Lakefront", lat: 22.3057, lng: 73.193 },
  ],
  Rajkot: [{ name: "Race Course Ground", lat: 22.305, lng: 70.7833 }],
};

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, x-admin-secret",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

export default async (req) => {
  const store = getStore("solosaathi");
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });

  if (req.method === "GET") {
    let table = await store.get("venues", { type: "json" });
    if (!table) {
      table = SEED_VENUES;
      await store.setJSON("venues", table);
    }
    return new Response(JSON.stringify(table), { status: 200, headers });
  }

  if (req.method === "POST") {
    const adminSecret = req.headers.get("x-admin-secret");
    if (!process.env.ADMIN_SECRET || adminSecret !== process.env.ADMIN_SECRET) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
    }
    const body = await req.json().catch(() => null);
    if (!body || typeof body.table !== "object") {
      return new Response(JSON.stringify({ error: "Expected { table: { City: [{name, lat, lng}] } }" }), { status: 400, headers });
    }
    await store.setJSON("venues", body.table);
    return new Response(JSON.stringify({ ok: true }), { status: 200, headers });
  }

  return new Response("Method not allowed", { status: 405, headers });
};
