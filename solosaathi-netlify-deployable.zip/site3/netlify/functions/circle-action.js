import { getStore } from "@netlify/blobs";

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers });

  const body = await req.json().catch(() => null);
  if (!body || !body.action) {
    return new Response(JSON.stringify({ error: "Missing action" }), { status: 400, headers });
  }

  const store = getStore("solosaathi");

  // Show-up response is keyed by venue, not circle — separate path.
  if (body.action === "showup") {
    if (!body.city || !body.venue || !["yes", "no"].includes(body.response)) {
      return new Response(JSON.stringify({ error: "Expected { action: 'showup', city, venue, response: 'yes'|'no' }" }), { status: 400, headers });
    }
    const key = `showups:${body.city}:${body.venue}`;
    const list = (await store.get(key, { type: "json" }).catch(() => null)) || [];
    list.push(body.response);
    await store.setJSON(key, list);
    return new Response(JSON.stringify({ ok: true }), { status: 200, headers });
  }

  if (!body.circleId) {
    return new Response(JSON.stringify({ error: "circleId is required" }), { status: 400, headers });
  }

  const stateKey = `circlestate:${body.circleId}`;
  let state = (await store.get(stateKey, { type: "json" }).catch(() => null)) || {
    locked: false,
    openSlots: 0,
    captainName: null,
    leftMembers: [],
    log: [],
  };

  switch (body.action) {
    case "grow": {
      const n = Math.max(1, Math.min(20, parseInt(body.count, 10) || 1));
      state.openSlots += n;
      state.locked = false;
      state.log.push({ text: `${body.byName || "Someone"} opened ${n} more spot${n > 1 ? "s" : ""}`, at: Date.now() });
      break;
    }
    case "lock": {
      state.locked = true;
      state.openSlots = 0;
      state.log.push({ text: `${body.byName || "Someone"} locked this Circle`, at: Date.now() });
      break;
    }
    case "leave": {
      if (!body.name) return new Response(JSON.stringify({ error: "name is required to leave" }), { status: 400, headers });
      state.leftMembers.push(body.name);
      state.openSlots += 1;
      state.log.push({ text: `${body.name} left the Circle — a slot is open`, at: Date.now() });
      break;
    }
    case "transfer": {
      if (!body.newCaptainName) return new Response(JSON.stringify({ error: "newCaptainName is required" }), { status: 400, headers });
      state.captainName = body.newCaptainName;
      state.log.push({ text: `${body.newCaptainName} is now Captain`, at: Date.now() });
      break;
    }
    default:
      return new Response(JSON.stringify({ error: `Unknown action: ${body.action}` }), { status: 400, headers });
  }

  await store.setJSON(stateKey, state);
  return new Response(JSON.stringify({ ok: true, state }), { status: 200, headers });
};
