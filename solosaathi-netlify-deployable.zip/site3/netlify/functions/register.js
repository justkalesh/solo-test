import { getStore } from "@netlify/blobs";
import { priceForDate, todayDateString } from "../../shared/pricing.js";
import { isLiveRegistrationOpen } from "../../shared/timing.js";
import { shouldStartNewBucket, circleName, landmarkFor, zoneFor, genderPref } from "../../shared/matching.js";
import { isWhatsAppVerified } from "../../shared/verification.js";
import { normalizeWhatsApp } from "../../shared/otp.js";

const REQUIRED_FIELDS = ["serial", "name", "whatsapp", "city", "venue", "level"];

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, x-admin-secret",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });

  const store = getStore("solosaathi");

  if (req.method === "POST") {
    const body = await req.json().catch(() => null);
    if (!body) return new Response(JSON.stringify({ error: "Invalid JSON body" }), { status: 400, headers });

    const missing = REQUIRED_FIELDS.filter((f) => !body[f] || String(body[f]).trim() === "");
    if (missing.length > 0) {
      return new Response(JSON.stringify({ error: "Missing required fields", missing }), { status: 400, headers });
    }

    const whatsapp = normalizeWhatsApp(body.whatsapp);
    if (!/^\d{10}$/.test(whatsapp)) {
      return new Response(JSON.stringify({ error: "WhatsApp number must be 10 digits" }), { status: 400, headers });
    }

    // Hard block, enforced here — not just in the UI. A request that
    // bypasses the OTP screen entirely still gets rejected.
    const verified = await isWhatsAppVerified(store, whatsapp);
    if (!verified) {
      return new Response(
        JSON.stringify({ error: "This WhatsApp number hasn't been verified. Complete OTP verification first." }),
        { status: 403, headers }
      );
    }

    const now = new Date();
    if (!isLiveRegistrationOpen(now)) {
      return new Response(
        JSON.stringify({ error: "Live registration is closed right now — check the event dates and daily hours." }),
        { status: 403, headers }
      );
    }

    const today = todayDateString();
    const price = priceForDate(today);
    const gender = ["male", "female"].includes(String(body.gender || "").toLowerCase())
      ? String(body.gender).toLowerCase()
      : "unstated";
    const pref = genderPref(gender, body.groupPreference);
    const bucketKey = `groupstate:${body.city}:${body.venue}:${body.level}:${pref}:${today}`;

    let state = await store.get(bucketKey, { type: "json" }).catch(() => null);
    if (!state) state = { groupIndex: 1, total: 0, male: 0, female: 0 };

    if (shouldStartNewBucket(state, gender, pref)) {
      state = { groupIndex: state.groupIndex + 1, total: 0, male: 0, female: 0 };
    }
    state.total += 1;
    if (gender === "male") state.male += 1;
    if (gender === "female") state.female += 1;
    await store.setJSON(bucketKey, state);

    const bucketIndex = state.groupIndex;
    const circleId = circleName(body.level, pref, bucketIndex);
    const landmark = landmarkFor(bucketIndex);
    const zone = zoneFor(bucketIndex);
    const token = `SOLO-PASS-${Date.now().toString(36).toUpperCase()}-${circleId}`;
    const isSmallWomenCircle = pref === "women" && state.total < 10;

    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const record = {
      id,
      ...body,
      whatsapp,
      circleId,
      landmark,
      zone,
      token,
      amountPaid: price,
      phase: "live",
      groupPreference: pref,
      isSmallWomenCircle,
      registeredAt: new Date().toISOString(),
    };
    await store.setJSON(`registration:${id}`, record);
    await store.set(`bymobile:${whatsapp}:${today}`, id);

    return new Response(
      JSON.stringify({ ok: true, circleId, landmark, zone, token, price, id, groupPreference: pref, isSmallWomenCircle }),
      { status: 200, headers }
    );
  }

  if (req.method === "GET") {
    const adminSecret = req.headers.get("x-admin-secret");
    if (!process.env.ADMIN_SECRET || adminSecret !== process.env.ADMIN_SECRET) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
    }
    const { blobs } = await store.list({ prefix: "registration:" });
    const records = await Promise.all(blobs.map((b) => store.get(b.key, { type: "json" })));
    return new Response(JSON.stringify(records), { status: 200, headers });
  }

  return new Response("Method not allowed", { status: 405, headers });
};
