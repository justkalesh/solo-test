import { getStore } from "@netlify/blobs";
import { circleName, landmarkFor, zoneFor } from "../../shared/matching.js";

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, x-admin-secret",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// NOTE ON PRODUCTION ARCHITECTURE:
// This endpoint does the finalization work, but something needs to *call*
// it at the right time. Two real triggers to implement:
//   1. A Netlify Scheduled Function (cron) running every 15-30 min, checking
//      every open pending bucket's eventDate, and calling this endpoint for
//      any bucket now within 48 hours of its event — this is what makes the
//      "you'll hear by 48h before" promise actually true automatically.
//   2. An organic trigger: call this endpoint whenever a bucket's size
//      crosses a healthy threshold (e.g. 12+), so popular nights finalize
//      early rather than waiting for the 48h deadline.
// For now this is a manually-callable, admin-authenticated endpoint so a
// developer can wire either trigger on top of it.

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers });

  const adminSecret = req.headers.get("x-admin-secret");
  if (!process.env.ADMIN_SECRET || adminSecret !== process.env.ADMIN_SECRET) {
    return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers });
  }

  const body = await req.json().catch(() => null);
  if (!body || !body.bucketKey) {
    return new Response(JSON.stringify({ error: "bucketKey is required" }), { status: 400, headers });
  }

  const store = getStore("solosaathi");
  const pool = await store.get(body.bucketKey, { type: "json" }).catch(() => null);
  if (!pool || pool.length === 0) {
    return new Response(JSON.stringify({ error: "This bucket is empty or does not exist" }), { status: 404, headers });
  }

  // bucketKey shape: pending:{city}:{venue}:{level}:{pref}:{eventDate}
  const [, city, venue, level, pref, eventDate] = body.bucketKey.split(":");
  const groupIndex = Math.floor(Math.random() * 90) + 1;
  const circleId = circleName(level, pref, groupIndex);
  const landmark = landmarkFor(groupIndex);
  const zone = zoneFor(groupIndex);

  const captain = pool.find((e) => e.iceBreaker) || pool[0];
  const roster = pool.map((e) => ({ name: e.name, tag: e === captain ? "CAPTAIN" : null, level }));

  const results = [];
  for (const entrant of pool) {
    const token = `SOLO-PASS-${Date.now().toString(36).toUpperCase()}-${circleId}-${entrant.name.slice(0, 2)}`;
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const record = {
      id,
      name: entrant.name,
      whatsapp: entrant.whatsapp,
      gender: entrant.gender,
      level,
      city,
      venue,
      eventDate,
      circleId,
      landmark,
      zone,
      token,
      memberCount: pool.length,
      roster,
      groupPreference: pref,
      phase: "advance",
      registeredAt: new Date().toISOString(),
    };
    await store.setJSON(`registration:${id}`, record);
    await store.set(`bymobile:${entrant.whatsapp}:${eventDate}`, id);
    results.push({ whatsapp: entrant.whatsapp, token });

    // --- REAL INTEGRATION NEEDED HERE ---
    // Fire the "Group formed" WhatsApp notification to entrant.whatsapp now,
    // using the same WhatsApp send function pattern as send-otp.js (a
    // "utility" category template, not authentication — different approval
    // category, same BSP). Message should include circleId, memberCount,
    // landmark, and the offline verification token.
  }

  await store.delete(body.bucketKey);

  return new Response(
    JSON.stringify({ ok: true, circleId, memberCount: pool.length, notified: results.length }),
    { status: 200, headers }
  );
};
