import { getStore } from "@netlify/blobs";
import { priceForDate } from "../../shared/pricing.js";
import { isAdvanceRegistrationOpen } from "../../shared/timing.js";
import { genderPref } from "../../shared/matching.js";
import { isWhatsAppVerified } from "../../shared/verification.js";
import { normalizeWhatsApp } from "../../shared/otp.js";

const REQUIRED_FIELDS = ["name", "whatsapp", "city", "venue", "eventDate", "level"];

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers });

  const store = getStore("solosaathi");
  const body = await req.json().catch(() => null);
  if (!body) return new Response(JSON.stringify({ error: "Invalid JSON body" }), { status: 400, headers });

  const missing = REQUIRED_FIELDS.filter((f) => !body[f] || String(body[f]).trim() === "");
  if (missing.length > 0) {
    return new Response(JSON.stringify({ error: "Missing required fields", missing }), { status: 400, headers });
  }

  // Ticket photo is mandatory for advance registration (no live physical
  // presence signal exists yet, so the ticket is the only fraud check
  // available). Enforce that a verify-ticket.js call actually ran and
  // produced a plausible result before accepting this registration.
  if (!body.ticketVerifiedToken) {
    return new Response(JSON.stringify({ error: "Ticket verification is required before advance registration" }), { status: 400, headers });
  }

  const whatsapp = normalizeWhatsApp(body.whatsapp);
  if (!/^\d{10}$/.test(whatsapp)) {
    return new Response(JSON.stringify({ error: "WhatsApp number must be 10 digits" }), { status: 400, headers });
  }

  const verified = await isWhatsAppVerified(store, whatsapp);
  if (!verified) {
    return new Response(
      JSON.stringify({ error: "This WhatsApp number hasn't been verified. Complete OTP verification first." }),
      { status: 403, headers }
    );
  }

  const now = new Date();
  if (!isAdvanceRegistrationOpen(now, body.eventDate)) {
    return new Response(
      JSON.stringify({ error: "Advance registration for this date has closed — register live at the venue instead." }),
      { status: 403, headers }
    );
  }

  const gender = ["male", "female"].includes(String(body.gender || "").toLowerCase())
    ? String(body.gender).toLowerCase()
    : "unstated";
  const pref = genderPref(gender, body.groupPreference);
  const bucketKey = `pending:${body.city}:${body.venue}:${body.level}:${pref}:${body.eventDate}`;

  const entry = {
    name: body.name,
    whatsapp,
    gender,
    iceBreaker: !!body.iceBreaker,
    level: body.level,
    joinedPoolAt: new Date().toISOString(),
  };

  const pool = (await store.get(bucketKey, { type: "json" }).catch(() => null)) || [];
  pool.push(entry);
  await store.setJSON(bucketKey, pool);

  const price = priceForDate(body.eventDate);

  return new Response(
    JSON.stringify({ ok: true, bucketKey, poolSize: pool.length, price }),
    { status: 200, headers }
  );
};
