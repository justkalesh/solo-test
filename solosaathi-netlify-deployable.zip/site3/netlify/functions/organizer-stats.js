import { getStore } from "@netlify/blobs";

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};

// Deterministic ID/password derivation for launch — replace with a real
// per-venue credential store (a Blobs-backed table you manage from the
// admin panel) once you have actual venues onboarded. Deterministic
// passwords are fine for a demo, not for anything real: anyone who can
// guess a venue name can derive its password.
function venueId(city, venue) {
  const cityPart = (city || "").replace(/[^A-Za-z]/g, "").slice(0, 2).toUpperCase();
  const venuePart = (venue || "").replace(/[^A-Za-z]/g, "").slice(0, 4).toUpperCase();
  return `${cityPart}-${venuePart}`;
}
function expectedPassword(venue) {
  return (venue || "").toLowerCase().replace(/[^a-z]/g, "").slice(0, 4) + "2026";
}

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (req.method !== "GET") return new Response("Method not allowed", { status: 405, headers });

  const url = new URL(req.url);
  const id = (url.searchParams.get("id") || "").toUpperCase().trim();
  const password = url.searchParams.get("password") || "";

  const store = getStore("solosaathi");
  const venueTable = (await store.get("venues", { type: "json" }).catch(() => null)) || {};

  let match = null;
  for (const city of Object.keys(venueTable)) {
    for (const v of venueTable[city]) {
      if (venueId(city, v.name) === id) match = { city, venue: v.name };
    }
  }
  if (!match) return new Response(JSON.stringify({ error: "Venue ID not recognized" }), { status: 401, headers });
  if (password !== expectedPassword(match.venue)) {
    return new Response(JSON.stringify({ error: "Incorrect password" }), { status: 401, headers });
  }

  const { blobs } = await store.list({ prefix: "registration:" });
  const all = await Promise.all(blobs.map((b) => store.get(b.key, { type: "json" })));
  const entries = all.filter((e) => e && e.city === match.city && e.venue === match.venue);

  const advanceCount = entries.filter((e) => e.phase === "advance").length;
  const liveCount = entries.length - advanceCount;

  const levelCounts = { beginner: 0, intermediate: 0, advanced: 0 };
  entries.forEach((e) => { if (levelCounts[e.level] !== undefined) levelCounts[e.level]++; });

  const genderCounts = { male: 0, female: 0, unstated: 0 };
  entries.forEach((e) => { const g = e.gender || "unstated"; if (genderCounts[g] !== undefined) genderCounts[g]++; });

  const uniqueCircles = {};
  entries.forEach((e) => { uniqueCircles[e.circleId] = e; });
  const circles = Object.values(uniqueCircles);
  const womenCircles = circles.filter((c) => c.groupPreference === "women");
  const avgSize = circles.length ? circles.reduce((s, c) => s + (c.memberCount || 1), 0) / circles.length : 0;
  const avgWomenSize = womenCircles.length ? womenCircles.reduce((s, c) => s + (c.memberCount || 1), 0) / womenCircles.length : 0;

  // Show-up rate reads from a separate store — see circle-action.js "showup" action.
  const showUps = (await store.get(`showups:${match.city}:${match.venue}`, { type: "json" }).catch(() => null)) || [];
  const showUpRate = showUps.length ? Math.round((showUps.filter((s) => s === "yes").length / showUps.length) * 100) : null;

  // Deliberately no money, no names, no phone numbers, no individual
  // records anywhere in this response — aggregate counts only.
  return new Response(
    JSON.stringify({
      venue: match.venue,
      city: match.city,
      totalRegistrations: entries.length,
      advanceCount,
      liveCount,
      levelCounts,
      genderCounts,
      circlesFormed: circles.length,
      avgCircleSize: Number(avgSize.toFixed(1)),
      allWomenCircles: womenCircles.length,
      avgAllWomenCircleSize: Number(avgWomenSize.toFixed(1)),
      showUpRatePercent: showUpRate,
      showUpResponses: showUps.length,
    }),
    { status: 200, headers }
  );
};
