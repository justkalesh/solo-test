// IMPORTANT CONTEXT FOR WHOEVER IMPLEMENTS THIS:
// The original prototype called Anthropic's API directly from the browser.
// That only worked because it was running inside a special claude.ai
// artifact runtime that injects credentials automatically — confirmed by
// testing that a plain fetch() to api.anthropic.com from an ordinary browser
// fails outright. On a real deployed site, this call MUST go through your
// own backend (this function), with the API key stored server-side only.
// Never ship a build that calls api.anthropic.com directly from client code
// — that would expose your key to anyone who opens dev tools.

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers });

  if (!process.env.ANTHROPIC_API_KEY) {
    return new Response(JSON.stringify({ error: "ANTHROPIC_API_KEY not configured on the server" }), { status: 500, headers });
  }

  const body = await req.json().catch(() => null);
  if (!body || !body.imageBase64 || !body.mediaType) {
    return new Response(JSON.stringify({ error: "Expected { imageBase64, mediaType }" }), { status: 400, headers });
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": process.env.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 300,
        system:
          "You extract structured data from event ticket or pass images. Respond ONLY with a single valid JSON object, no markdown fences, no explanation. If a field is not visible or you are not confident, use null for that field.",
        messages: [
          {
            role: "user",
            content: [
              { type: "image", source: { type: "base64", media_type: body.mediaType, data: body.imageBase64 } },
              {
                type: "text",
                text:
                  'This ticket may be in English, Hindi, Gujarati, Marathi, or another Indian language, from any platform (BookMyShow, District, Paytm Insider, a custom pass, etc). Extract: {"city": string or null, "venue": string or null, "venue_english": string or null, "pass_id": string or null, "looks_like_valid_ticket": boolean}. Respond with only that JSON object.',
              },
            ],
          },
        ],
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      return new Response(JSON.stringify({ error: `Anthropic API error: ${response.status}`, detail: errText }), { status: 502, headers });
    }

    const data = await response.json();
    const textBlock = (data.content || []).find((b) => b.type === "text");
    const cleaned = (textBlock ? textBlock.text : "").replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(cleaned);

    // A lightweight token the frontend passes along to advance-register.js
    // to prove this check actually ran, without re-sending the whole image.
    const ticketVerifiedToken = `TVT-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

    return new Response(JSON.stringify({ ...parsed, ticketVerifiedToken }), { status: 200, headers });
  } catch (err) {
    return new Response(JSON.stringify({ error: "Ticket verification failed", detail: String(err) }), { status: 500, headers });
  }
};
