import { getStore } from "@netlify/blobs";
import { normalizeWhatsApp, OTP_MAX_VERIFY_ATTEMPTS, VERIFIED_TTL_MS } from "../../shared/otp.js";

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers });

  const body = await req.json().catch(() => null);
  const whatsapp = normalizeWhatsApp(body && body.whatsapp);
  const code = String((body && body.code) || "").trim();
  if (!/^\d{10}$/.test(whatsapp) || !code) {
    return new Response(JSON.stringify({ error: "Missing WhatsApp number or code" }), { status: 400, headers });
  }

  const store = getStore("solosaathi");
  const otpKey = `otp:${whatsapp}`;
  const record = await store.get(otpKey, { type: "json" }).catch(() => null);

  if (!record) {
    return new Response(JSON.stringify({ error: "No active code for this number — request a new one" }), { status: 400, headers });
  }
  if (Date.now() > record.expiresAt) {
    await store.delete(otpKey).catch(() => {});
    return new Response(JSON.stringify({ error: "Code expired — request a new one" }), { status: 400, headers });
  }

  if (code !== record.code) {
    record.attempts = (record.attempts || 0) + 1;
    // Hard block, by design: once attempts are exhausted, the code is
    // invalidated outright. There is no manual override path — someone who
    // can never enter the correct code (because it isn't their number)
    // simply cannot proceed. This is intentional: it's the mechanism that
    // stops registration on a number the registrant doesn't control.
    if (record.attempts >= OTP_MAX_VERIFY_ATTEMPTS) {
      await store.delete(otpKey).catch(() => {});
      return new Response(JSON.stringify({ error: "Too many incorrect attempts — request a new code" }), { status: 403, headers });
    }
    await store.setJSON(otpKey, record);
    return new Response(
      JSON.stringify({ ok: false, remainingAttempts: OTP_MAX_VERIFY_ATTEMPTS - record.attempts }),
      { status: 200, headers }
    );
  }

  // Correct code — mark this number verified for a limited window, checked
  // server-side by register.js / advance-register.js before accepting a
  // registration. This is what makes the block real, not just a UI gate.
  await store.delete(otpKey).catch(() => {});
  await store.setJSON(`verified:${whatsapp}`, { verifiedAt: Date.now() });

  return new Response(JSON.stringify({ ok: true }), { status: 200, headers });
};
