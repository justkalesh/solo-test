import { getStore } from "@netlify/blobs";
import {
  generateOtp,
  normalizeWhatsApp,
  OTP_EXPIRY_MS,
  OTP_MAX_SENDS_PER_WINDOW,
  OTP_SEND_WINDOW_MS,
  OTP_RESEND_COOLDOWN_MS,
} from "../../shared/otp.js";

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// --- REAL INTEGRATION NEEDED HERE ---
// Wire this up to your WhatsApp Business Solution Provider (Interakt,
// AiSensy, Gupshup, or Meta's Cloud API directly). You'll need:
//   1. A Meta Business verification + WhatsApp Business Account (WABA)
//   2. An approved "authentication" template (fast-track category — submit
//      wording like: "Your SoloSaathi verification code is {{1}}. Valid for
//      10 minutes. Do not share this code.")
//   3. Your BSP's API key stored as WHATSAPP_API_KEY in Netlify env vars
// Current Meta rate (verified 2026): ~₹0.115 per authentication message,
// domestic. No DLT registration needed for WhatsApp (unlike SMS).
async function sendWhatsAppOtp(whatsapp, code) {
  if (!process.env.WHATSAPP_API_KEY) {
    throw new Error("WHATSAPP_API_KEY not configured");
  }
  // Example shape for most BSPs — replace with your provider's actual
  // endpoint and payload format from their docs.
  const res = await fetch(process.env.WHATSAPP_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${process.env.WHATSAPP_API_KEY}`,
    },
    body: JSON.stringify({
      to: `91${whatsapp}`,
      template: "solosaathi_otp", // the template name you got approved
      params: [code],
    }),
  });
  if (!res.ok) throw new Error(`WhatsApp send failed: ${res.status}`);
}

// --- FALLBACK: SMS via a DLT-registered route ---
// Only needed if WhatsApp delivery fails (number not on WhatsApp, etc).
// Requires a DLT-registered sender ID + template with an SMS provider
// (MSG91, Kaleyra) — budget 1-2 weeks lead time for DLT approval, separate
// from the WhatsApp setup above.
async function sendSmsOtpFallback(whatsapp, code) {
  if (!process.env.SMS_API_KEY) {
    throw new Error("SMS_API_KEY not configured — no fallback available");
  }
  const res = await fetch(process.env.SMS_API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${process.env.SMS_API_KEY}` },
    body: JSON.stringify({ to: `91${whatsapp}`, template_id: process.env.SMS_DLT_TEMPLATE_ID, code }),
  });
  if (!res.ok) throw new Error(`SMS fallback send failed: ${res.status}`);
}

export default async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers });
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405, headers });

  const body = await req.json().catch(() => null);
  const whatsapp = normalizeWhatsApp(body && body.whatsapp);
  if (!/^\d{10}$/.test(whatsapp)) {
    return new Response(JSON.stringify({ error: "Enter a valid 10-digit WhatsApp number" }), { status: 400, headers });
  }

  const store = getStore("solosaathi");
  const now = Date.now();

  // Rate limiting — critical, since every send costs real money and a
  // stranger could otherwise spam OTPs to a number they don't own.
  const rlKey = `otp-rl:${whatsapp}`;
  let rl = await store.get(rlKey, { type: "json" }).catch(() => null);
  if (!rl || now - rl.windowStart > OTP_SEND_WINDOW_MS) {
    rl = { windowStart: now, count: 0, lastSentAt: 0 };
  }
  if (now - rl.lastSentAt < OTP_RESEND_COOLDOWN_MS) {
    const waitSec = Math.ceil((OTP_RESEND_COOLDOWN_MS - (now - rl.lastSentAt)) / 1000);
    return new Response(JSON.stringify({ error: `Please wait ${waitSec}s before requesting another code` }), { status: 429, headers });
  }
  if (rl.count >= OTP_MAX_SENDS_PER_WINDOW) {
    return new Response(JSON.stringify({ error: "Too many code requests — please try again in 15 minutes" }), { status: 429, headers });
  }

  const code = generateOtp();
  await store.setJSON(`otp:${whatsapp}`, { code, expiresAt: now + OTP_EXPIRY_MS, attempts: 0 });
  rl.count += 1;
  rl.lastSentAt = now;
  await store.setJSON(rlKey, rl);

  let devCode; // only ever populated in explicit dev mode, see below
  try {
    await sendWhatsAppOtp(whatsapp, code);
  } catch (whatsappErr) {
    try {
      await sendSmsOtpFallback(whatsapp, code);
    } catch (smsErr) {
      // Neither is configured yet — this is expected until a developer
      // wires up real credentials. Never do this in a live production
      // deployment: OTP_DEV_MODE must not be set once real users register.
      if (process.env.OTP_DEV_MODE === "true") {
        devCode = code;
      } else {
        return new Response(
          JSON.stringify({ error: "OTP delivery is not configured yet. Set WHATSAPP_API_KEY (and optionally SMS_API_KEY) in Netlify environment variables." }),
          { status: 500, headers }
        );
      }
    }
  }

  return new Response(JSON.stringify({ ok: true, expiresInSec: OTP_EXPIRY_MS / 1000, devCode }), { status: 200, headers });
};
