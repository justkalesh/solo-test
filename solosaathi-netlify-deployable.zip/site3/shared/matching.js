// Matching rules shared across register.js (live) and finalize-bucket.js
// (advance). Kept in one place so the live and advance paths can never
// silently diverge on how a "fair" circle is defined.

export const GENDER_CAP = 10; // per-group ceiling on any single declared gender in a MIXED circle
export const SOFT_MAX_GROUP = 24; // no hard cap on circle size, but avoid one bucket growing forever
export const ALL_WOMEN_MIN_FLOOR = 4; // preferred minimum to close an all-women circle at
export const ALL_WOMEN_ABSOLUTE_MIN = 3; // last-resort minimum if truly stuck

const LANDMARKS = [
  "Near Main Stage / Stall 5",
  "Near Gate 2 / Food Court",
  "Near First Aid Tent",
  "Near Parking Entrance",
];
const ZONES = ["H1", "H2", "H3", "H4"];

export function circleName(level, pref, bucketIndex) {
  const prefix =
    pref === "women" ? "SAKHI" : level === "advanced" ? "RAAS" : level === "intermediate" ? "TAAL" : "GARBA";
  return `${prefix}-${String(bucketIndex).padStart(2, "0")}`;
}

export function landmarkFor(bucketIndex) {
  return LANDMARKS[bucketIndex % LANDMARKS.length];
}

export function zoneFor(bucketIndex) {
  return ZONES[bucketIndex % ZONES.length];
}

export function genderPref(gender, groupPreference) {
  return gender === "female" && groupPreference === "all_women" ? "women" : "mixed";
}

// Given a bucket's current running state, decide whether this new entrant
// should join it or start a fresh bucket. Same logic for live (continuous)
// and advance (batch-finalized) matching.
export function shouldStartNewBucket(state, gender, pref) {
  if (state.total >= SOFT_MAX_GROUP) return true;
  if (pref !== "mixed") return false; // no gender-cap concept in an all-women circle
  if (gender === "male" && state.male >= GENDER_CAP) return true;
  if (gender === "female" && state.female >= GENDER_CAP) return true;
  return false;
}
