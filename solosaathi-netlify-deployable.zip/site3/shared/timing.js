// Single source of truth for all calendar/time gating — imported by every
// function that needs to know "is registration open right now" so the rule
// can never drift between endpoints.

export const LIVE_ENABLED_FROM = "2026-10-13"; // event season start — live walk-in only works from this date
export const REG_OPEN_MINUTES = 18 * 60 + 30; // 6:30 PM
export const REG_CLOSE_MINUTES = 1 * 60 + 30; // 1:30 AM (wraps past midnight)
export const CHAT_CLOSE_MINUTES = 1 * 60; // 1:00 AM

// Netlify Functions run in UTC by default, but every time in this app is
// meant in IST. Every function below converts to IST before extracting
// hours/date — this was a real bug during development (caught by tests):
// checking raw UTC hours against IST-intended window boundaries silently
// shifted every gate by 5.5 hours. Don't remove the toIST() calls.
function toIST(date) {
  return new Date(date.getTime() + 5.5 * 60 * 60 * 1000);
}

function minutesOf(date) {
  const ist = toIST(date);
  return ist.getUTCHours() * 60 + ist.getUTCMinutes();
}

export function isBeforeLiveSeason(now) {
  return toIST(now).toISOString().slice(0, 10) < LIVE_ENABLED_FROM;
}

export function isWithinDailyWindow(now) {
  const m = minutesOf(now);
  return m >= REG_OPEN_MINUTES || m < REG_CLOSE_MINUTES;
}

export function isLiveRegistrationOpen(now) {
  return !isBeforeLiveSeason(now) && isWithinDailyWindow(now);
}

export function isPastChatClose(now) {
  const m = minutesOf(now);
  return m >= CHAT_CLOSE_MINUTES && m < REG_OPEN_MINUTES;
}

// Advance registration stays open through day-of, closing only once the
// live/at-venue phase begins — NOT a 48-hour cutoff (see matching.js for
// the 48h *finalization* promise, which is a separate, softer commitment).
export function isAdvanceRegistrationOpen(now, eventDateStr) {
  // Open any time up until 2 hours before the specific event's start,
  // assuming a 7:30 PM IST default start. The explicit +05:30 offset is
  // required — without it, this would parse as 7:30 PM UTC on whatever
  // server timezone Node defaults to, not IST.
  const eventStart = new Date(eventDateStr + "T19:30:00+05:30");
  const cutoff = new Date(eventStart.getTime() - 2 * 60 * 60 * 1000);
  return now < cutoff;
}
