// OTP rules — shared so send-otp.js and verify-otp.js can never disagree on
// what counts as expired, or how many attempts are allowed.

export const OTP_LENGTH = 6;
export const OTP_EXPIRY_MS = 10 * 60 * 1000; // 10 minutes
export const OTP_MAX_VERIFY_ATTEMPTS = 5; // wrong guesses allowed before the code is invalidated
export const OTP_MAX_SENDS_PER_WINDOW = 3; // sends allowed per number...
export const OTP_SEND_WINDOW_MS = 15 * 60 * 1000; // ...per this many minutes
export const OTP_RESEND_COOLDOWN_MS = 30 * 1000; // minimum gap between consecutive sends
export const VERIFIED_TTL_MS = 30 * 60 * 1000; // how long a "verified" mark stays valid before registration must be completed

export function generateOtp() {
  const min = 10 ** (OTP_LENGTH - 1);
  const max = 10 ** OTP_LENGTH - 1;
  return String(Math.floor(min + Math.random() * (max - min + 1)));
}

export function normalizeWhatsApp(raw) {
  return String(raw || "").replace(/\D/g, "").slice(-10);
}
