import { VERIFIED_TTL_MS } from "./otp.js";

// The actual hard-block enforcement lives here, checked server-side by every
// endpoint that creates a registration. A client that skips the OTP UI
// entirely still cannot register, because this check happens on the server,
// not just in the form.
export async function isWhatsAppVerified(store, whatsapp) {
  const record = await store.get(`verified:${whatsapp}`, { type: "json" }).catch(() => null);
  if (!record) return false;
  return Date.now() - record.verifiedAt < VERIFIED_TTL_MS;
}
