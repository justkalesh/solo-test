// Single source of truth for pricing — imported by both the frontend (what
// the button shows) and every backend function that charges money, so they
// can never drift apart.

export const BASE_PRICE = 199;
export const PEAK_PRICE = 249;

// TODO: set your actual Navratri peak dates here, in YYYY-MM-DD format.
// A common pattern is weekends, Ashtami, and the last day or two.
export const PEAK_DATES = [
  "2026-10-17",
  "2026-10-18",
  "2026-10-24",
  "2026-10-25",
];

export function priceForDate(dateStr) {
  return PEAK_DATES.includes(dateStr) ? PEAK_PRICE : BASE_PRICE;
}

export function todayDateString() {
  return new Date().toISOString().slice(0, 10);
}
