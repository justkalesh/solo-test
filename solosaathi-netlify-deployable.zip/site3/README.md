# SoloSaathi Circle — Deployable Netlify Project

This is the real, deployable backend + core frontend for SoloSaathi Circle,
built on Netlify Functions + Netlify Blobs. It is meant to be handed to a
developer to finish integrating real third-party services (WhatsApp,
payments, AI ticket verification) and to port over the remaining UI polish.

**Read this whole file before writing any code.** It tells you what's
already correct, what's stubbed out and why, and exactly what to wire up.

---

## 1. What's actually built here

### Backend (netlify/functions/) — fully implemented business logic
- `send-otp.js` / `verify-otp.js` — WhatsApp OTP verification, **hard block**
  by design (no manual override — see §4)
- `register.js` — Live walk-in registration: OTP-gated, date/time-gated,
  full matching (gender balance cap, all-women circles, even growth)
- `advance-register.js` — Advance registration: OTP-gated, mandatory ticket
  verification, feeds a pending pool (does not match instantly)
- `finalize-bucket.js` — Converts a pending pool into a real Circle
  (needs a scheduler wired on top — see §5)
- `verify-ticket.js` — Server-side AI ticket photo check (keeps your
  Anthropic key secret — see the comment at the top of this file, it
  explains why this *must* be server-side)
- `organizer-stats.js` — ID+password login, aggregate stats only (no money,
  no names, no phone numbers — this is enforced server-side, not just hidden
  in the UI)
- `circle-action.js` — grow / lock / leave / transfer-captain / show-up,
  backed by real shared state (this genuinely could not exist in a
  client-only prototype — there was no second real user to sync state with)
- `venues.js`, `find.js` — venue directory and multi-night "find my circle"
  lookup

### Shared logic (shared/) — unit-tested, not just written
`timing.js`, `matching.js`, `pricing.js`, `otp.js`, `verification.js` contain
every business rule (gender cap, all-women floor, IST time gates, OTP
expiry/rate-limits) as pure functions, so both the live and advance paths
use identically the same rules. **A real bug was caught and fixed during
this build**: the daily time window was being checked against raw UTC hours
instead of IST, which would have silently shifted every time-based gate by
5.5 hours. Worth knowing this class of bug exists — if you touch `timing.js`,
re-run the IST boundary cases before trusting it.

### Frontend (src/App.jsx) — functional core only
Covers the real end-to-end flow: OTP verification → Live registration,
OTP verification → Advance registration → ticket check, Find my Circle,
and a basic Organizer Dashboard. This is plain, functional UI — **it does
not replicate the full festive visual design, animations, Beacon screen,
or polished Chat UI** from the earlier chat-preview prototype.

**The chat-preview file (`solosaathi-preview.jsx`, delivered separately) is
the authoritative UX/visual reference.** It has been extensively
browser-tested for exact copy, colors, animations, and interaction details.
Treat this project as "the plumbing is real and correct," and that file as
"this is exactly what it should look and feel like" — port the visual
layer from there into this project's components.

---

## 2. What is NOT tested, and why

I do not have a real Netlify deployment, a WhatsApp Business API account, a
payment gateway, or a live Anthropic API key in the environment this was
built in. So:

- ✅ **Tested**: every pure function in `shared/` (OTP generation/expiry,
  gender-cap matching, IST time boundaries) via standalone unit test scripts
- ✅ **Tested**: every file passes `node --check` (syntax-valid)
- ❌ **Not tested**: the functions running against real Netlify Blobs in a
  deployed environment
- ❌ **Not tested**: real WhatsApp OTP delivery, real SMS fallback, real
  payment capture, real Anthropic API calls from this backend

None of this is guesswork dressed up as done — it's flagged so you know
exactly where to point your first real end-to-end test once you deploy.

---

## 3. Environment variables you need to set in Netlify

| Variable | Purpose | Required for |
|---|---|---|
| `ADMIN_SECRET` | Protects the admin venue panel and `finalize-bucket.js` | Always |
| `WHATSAPP_API_KEY` | Your BSP's API key | OTP + notifications |
| `WHATSAPP_API_URL` | Your BSP's send endpoint | OTP + notifications |
| `SMS_API_KEY`, `SMS_API_URL`, `SMS_DLT_TEMPLATE_ID` | SMS fallback if WhatsApp delivery fails | Fallback path (agreed as in-scope) |
| `ANTHROPIC_API_KEY` | Server-side AI ticket check | Advance registration |
| `OTP_DEV_MODE` | Set to `"true"` ONLY on a local/dev deploy to echo OTP codes when no WhatsApp/SMS provider is configured. **Never set this in production** — it would let anyone see any number's OTP. | Local testing only |

---

## 4. WhatsApp OTP setup (the piece added before this build)

**Why this exists**: registration used to accept any typed WhatsApp number
with zero verification. That meant someone could register on a number they
don't own, and later dispute or claim a refund on a booking tied to a
number they never controlled. OTP closes that gap.

**Hard block, deliberately, no override**: if someone fails to verify a
number (wrong code too many times, or the code never arrives because it
isn't their real number), they **cannot** register — there is no manual
bypass. This was an explicit decision, not an oversight: the whole point is
to stop registration-on-a-stranger's-number abuse, and a manual override
would defeat that.

**Setup steps:**
1. Pick a Business Solution Provider (Interakt, AiSensy, or Gupshup are
   common in India) and complete Meta Business verification through them.
2. Submit an **authentication-category** template for approval. Suggested
   wording: *"Your SoloSaathi verification code is {{1}}. Valid for 10
   minutes. Do not share this code."* Authentication templates get a faster,
   more standardized review than marketing templates.
3. Get your API key and endpoint from the BSP, set as `WHATSAPP_API_KEY` /
   `WHATSAPP_API_URL`.
4. Wire the actual request shape into `sendWhatsAppOtp()` in
   `netlify/functions/send-otp.js` — the shape in there now is a
   placeholder; check your BSP's docs for their exact payload format.
5. (Optional, agreed as in-scope) Set up an SMS DLT-registered sender +
   template as a fallback for `sendSmsOtpFallback()` in the same file, for
   when WhatsApp delivery fails. Budget 1-2 weeks for DLT approval — this
   has a real lead time, unlike WhatsApp which needs no DLT registration.

**Verified current pricing (2026, India, subject to change — check Meta's
own pricing page before budgeting):**
- WhatsApp authentication (OTP) messages: **~₹0.115 per message**, domestic
- International numbers: **~₹2.30 per message** (about 20x more)
- No DLT registration needed for WhatsApp (SMS-only requirement)
- Your BSP will add its own platform fee on top of Meta's per-message rate

---

## 5. Production architecture notes — read before deploying

**Finalizing advance-registration pools** (`finalize-bucket.js`) needs
something to actually call it at the right time. Two triggers to implement:
1. A **Netlify Scheduled Function** (cron) checking every open pending
   bucket's event date, calling this endpoint for any bucket now within 48
   hours of its event — this is what makes the "you'll hear by 48h before"
   promise real rather than aspirational.
2. An organic trigger: call it whenever a bucket's size crosses a healthy
   threshold (e.g. 12+), so popular nights finalize early.

**Sending the "Group formed" notification** — there's a clearly marked TODO
comment inside `finalize-bucket.js` where this needs to fire. It's a
*utility*-category WhatsApp template (different approval category from the
authentication template used for OTP), same BSP.

**Payment gateway** — none of these functions currently charge money. The
frontend shows a price (from `shared/pricing.js`) but there's no Razorpay/
Cashfree integration yet. Wire that in before `register.js` /
`advance-register.js` are called, or add a payment-confirmation step
in between.

**Organizer credentials** — `organizer-stats.js` derives a venue's ID and
password deterministically from its name (e.g. "GMDC Ground" → ID `AH-GMDC`,
password `gmdc2026`). This is fine for early testing, not for anything real:
anyone who can guess a venue's name can derive its password. Replace with a
real per-venue credential store before onboarding actual organizers.

---

## 6. Local development

```bash
npm install
npm run dev          # frontend only, functions won't work without Netlify CLI
# or, for functions too:
netlify dev           # requires: npm install -g netlify-cli, netlify login
```

With no `WHATSAPP_API_KEY` set and `OTP_DEV_MODE=true`, `send-otp.js` will
return the generated code directly in its response so you can test the flow
without a real WhatsApp account. Double-check this env var is unset before
any real deployment.

## 7. Deploying

```bash
netlify init      # link to a Netlify site
netlify deploy --prod
```

Set all environment variables from §3 in the Netlify dashboard
(Site settings → Environment variables) before the first real deploy.

---

## 8. Checklist for the developer you're hiring

- [ ] Wire real WhatsApp send in `send-otp.js` and `finalize-bucket.js`
- [ ] (If in scope) wire SMS DLT fallback in `send-otp.js`
- [ ] Add a payment gateway step before registration completes
- [ ] Set up a Scheduled Function to call `finalize-bucket.js` automatically
- [ ] Replace deterministic organizer credentials with a real credential store
- [ ] Port the full visual design from `solosaathi-preview.jsx` into
      `src/App.jsx` — Beacon screen, chat UI polish, animations, exact copy
- [ ] Test everything end-to-end against a real Netlify deployment (nothing
      here has been tested against live Blobs, only unit-tested locally)
- [ ] Get the WhatsApp authentication template and utility (notification)
      template approved by Meta before launch — budget a few days
