import { useState, useEffect } from "react";

const BRAND = "Solo Saathi Circle";
const LEVELS = [
  { id: "beginner", label: "Beginner", icon: "🌱", color: "#22C55E" },
  { id: "intermediate", label: "Intermediate", icon: "⚡", color: "#FFB020" },
  { id: "advanced", label: "Pro Raas", icon: "🔥", color: "#F43F5E" },
];

const inputStyle = {
  width: "100%", boxSizing: "border-box", padding: "11px 12px", borderRadius: 10,
  border: "1px solid #4A3B6E", background: "#241D3D", color: "#F3EDE0", fontSize: 14,
};
const labelStyle = { display: "block", fontSize: 12, fontWeight: 700, color: "#B29CE0", marginBottom: 4 };
const cardStyle = { background: "#2A2049", borderRadius: 14, border: "1px solid #4A3B6E", padding: 16, marginBottom: 14 };
const buttonStyle = (disabled) => ({
  width: "100%", padding: "13px 18px", borderRadius: 10, border: "none", fontWeight: 700, fontSize: 15,
  background: disabled ? "#443B66" : "linear-gradient(90deg, #F5B301, #DB2777)",
  color: disabled ? "#8A81A8" : "#1B1730", cursor: disabled ? "not-allowed" : "pointer",
});
const ghostButtonStyle = { padding: "9px 14px", borderRadius: 8, border: "1px solid #4A3B6E", background: "#241D3D", color: "#C9BFE0", cursor: "pointer", fontSize: 13 };

function Field({ label, children, error }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <span style={labelStyle}>{label}</span>
      {children}
      {error && <div style={{ color: "#F43F5E", fontSize: 11, marginTop: 3 }}>{error}</div>}
    </div>
  );
}

// --- OTP verification, reused by both Live and Advance flows ---
function OtpGate({ whatsapp, onVerified }) {
  const [status, setStatus] = useState("idle"); // idle | sent | verified | error
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setInterval(() => setCooldown((c) => Math.max(0, c - 1)), 1000);
    return () => clearInterval(t);
  }, [cooldown]);

  async function sendOtp() {
    setError("");
    try {
      const res = await fetch("/.netlify/functions/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ whatsapp }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || "Could not send code"); return; }
      setStatus("sent");
      setCooldown(30);
      if (data.devCode) setError(`Dev mode — code is ${data.devCode} (OTP_DEV_MODE only, never in production)`);
    } catch (e) {
      setError("Network error sending code");
    }
  }

  async function verifyOtp() {
    setError("");
    try {
      const res = await fetch("/.netlify/functions/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ whatsapp, code }),
      });
      const data = await res.json();
      if (!res.ok) { setError(data.error || "Verification failed"); return; }
      if (!data.ok) { setError(`Incorrect code — ${data.remainingAttempts} attempt(s) left`); return; }
      setStatus("verified");
      onVerified(true);
    } catch (e) {
      setError("Network error verifying code");
    }
  }

  if (status === "verified") {
    return <div style={{ color: "#3EE07A", fontSize: 13, fontWeight: 700 }}>✓ WhatsApp number verified</div>;
  }

  return (
    <div style={cardStyle}>
      {status === "idle" && (
        <button style={buttonStyle(!/^\d{10}$/.test(whatsapp))} disabled={!/^\d{10}$/.test(whatsapp)} onClick={sendOtp}>
          Send OTP to verify WhatsApp number
        </button>
      )}
      {status === "sent" && (
        <>
          <Field label="Enter the 6-digit code">
            <input style={inputStyle} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="123456" />
          </Field>
          <button style={{ ...buttonStyle(code.length !== 6), marginBottom: 8 }} disabled={code.length !== 6} onClick={verifyOtp}>
            Verify
          </button>
          <button style={{ ...ghostButtonStyle, width: "100%", boxSizing: "border-box", opacity: cooldown > 0 ? 0.5 : 1 }} disabled={cooldown > 0} onClick={sendOtp}>
            {cooldown > 0 ? `Resend in ${cooldown}s` : "Resend code"}
          </button>
        </>
      )}
      {error && <div style={{ color: "#FFB020", fontSize: 12, marginTop: 8 }}>{error}</div>}
    </div>
  );
}

function useVenues() {
  const [venues, setVenues] = useState({});
  useEffect(() => {
    fetch("/.netlify/functions/venues").then((r) => r.json()).then(setVenues).catch(() => {});
  }, []);
  return venues;
}

function CityVenuePicker({ city, venue, onCity, onVenue }) {
  const venues = useVenues();
  return (
    <div style={{ display: "flex", gap: 10 }}>
      <Field label="City">
        <select style={inputStyle} value={city} onChange={(e) => { onCity(e.target.value); onVenue(""); }}>
          <option value="">Select</option>
          {Object.keys(venues).map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </Field>
      <Field label="Venue">
        <select style={inputStyle} value={venue} disabled={!city} onChange={(e) => onVenue(e.target.value)}>
          <option value="">{city ? "Select" : "City first"}</option>
          {(venues[city] || []).map((v) => <option key={v.name} value={v.name}>{v.name}</option>)}
        </select>
      </Field>
    </div>
  );
}

function LiveRegister({ onExit }) {
  const [form, setForm] = useState({ serial: "", name: "", whatsapp: "", city: "", venue: "", level: null, gender: "unstated", groupPreference: "mixed", iceBreaker: false });
  const [verified, setVerified] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  async function submit() {
    setError("");
    const res = await fetch("/.netlify/functions/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const data = await res.json();
    if (!res.ok) { setError(data.error || "Registration failed"); return; }
    setResult(data);
  }

  if (result) {
    return (
      <div style={cardStyle}>
        <h2 style={{ color: "#F3EDE0" }}>Circle #{result.circleId}</h2>
        <p style={{ color: "#B9AFD1" }}>Meet at {result.landmark}, Zone {result.zone}</p>
        <p style={{ color: "#8A81A8", fontSize: 12, wordBreak: "break-all" }}>{result.token}</p>
        <button style={ghostButtonStyle} onClick={onExit}>Done</button>
      </div>
    );
  }

  return (
    <div>
      <button style={{ ...ghostButtonStyle, marginBottom: 16 }} onClick={onExit}>← Exit</button>
      <h2 style={{ color: "#F3EDE0" }}>Live Registration</h2>
      <Field label="Ticket serial (or upload a photo — see README on wiring verify-ticket.js here)">
        <input style={inputStyle} value={form.serial} onChange={(e) => setForm({ ...form, serial: e.target.value })} />
      </Field>
      <CityVenuePicker city={form.city} venue={form.venue} onCity={(v) => setForm({ ...form, city: v })} onVenue={(v) => setForm({ ...form, venue: v })} />
      <Field label="Name"><input style={inputStyle} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
      <Field label="WhatsApp Number">
        <input style={inputStyle} value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value.replace(/\D/g, "").slice(0, 10) })} placeholder="10-digit" />
      </Field>
      <OtpGate whatsapp={form.whatsapp} onVerified={setVerified} />
      <Field label="Gender">
        <select style={inputStyle} value={form.gender} onChange={(e) => setForm({ ...form, gender: e.target.value })}>
          <option value="unstated">Prefer not to say</option>
          <option value="male">Male</option>
          <option value="female">Female</option>
        </select>
      </Field>
      {form.gender === "female" && (
        <Field label="Circle type">
          <select style={inputStyle} value={form.groupPreference} onChange={(e) => setForm({ ...form, groupPreference: e.target.value })}>
            <option value="mixed">Mixed circle</option>
            <option value="all_women">All-women circle</option>
          </select>
        </Field>
      )}
      <Field label="Garba Skill Level">
        <div style={{ display: "flex", gap: 8 }}>
          {LEVELS.map((l) => (
            <div key={l.id} onClick={() => setForm({ ...form, level: l.id })} style={{
              flex: 1, textAlign: "center", padding: 12, borderRadius: 10, cursor: "pointer",
              border: form.level === l.id ? `2px solid ${l.color}` : "1px solid #4A3B6E", color: "#F3EDE0",
            }}>
              <div>{l.icon}</div><div style={{ fontSize: 12 }}>{l.label}</div>
            </div>
          ))}
        </div>
      </Field>
      {error && <div style={{ color: "#F43F5E", marginBottom: 10 }}>{error}</div>}
      <button style={buttonStyle(!verified || !form.level)} disabled={!verified || !form.level} onClick={submit}>
        Find Solo Garba Circle
      </button>
    </div>
  );
}

function AdvanceRegister({ onExit }) {
  const [form, setForm] = useState({ name: "", whatsapp: "", city: "", venue: "", eventDate: "", level: null, gender: "unstated", groupPreference: "mixed", iceBreaker: false });
  const [verified, setVerified] = useState(false);
  const [ticketImage, setTicketImage] = useState(null);
  const [ticketToken, setTicketToken] = useState(null);
  const [ticketStatus, setTicketStatus] = useState("idle");
  const [result, setResult] = useState(null);
  const [error, setError] = useState("");

  function handleFile(e) {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      setTicketImage(reader.result);
      setTicketStatus("checking");
      const match = reader.result.match(/^data:(image\/[a-zA-Z]+);base64,(.+)$/);
      try {
        const res = await fetch("/.netlify/functions/verify-ticket", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ mediaType: match[1], imageBase64: match[2] }),
        });
        const data = await res.json();
        if (res.ok && data.ticketVerifiedToken) {
          setTicketToken(data.ticketVerifiedToken);
          setTicketStatus("done");
        } else {
          setTicketStatus("failed");
        }
      } catch {
        setTicketStatus("failed");
      }
    };
    reader.readAsDataURL(file);
  }

  async function submit() {
    setError("");
    const res = await fetch("/.netlify/functions/advance-register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, ticketVerifiedToken: ticketToken }),
    });
    const data = await res.json();
    if (!res.ok) { setError(data.error || "Registration failed"); return; }
    setResult(data);
  }

  if (result) {
    return (
      <div style={cardStyle}>
        <h2 style={{ color: "#F3EDE0" }}>You're in the pending pool!</h2>
        <p style={{ color: "#B9AFD1" }}>Your group will be formed and messaged to you on WhatsApp once ready, and no later than 48 hours before the event.</p>
        <button style={ghostButtonStyle} onClick={onExit}>Done</button>
      </div>
    );
  }

  return (
    <div>
      <button style={{ ...ghostButtonStyle, marginBottom: 16 }} onClick={onExit}>← Exit</button>
      <h2 style={{ color: "#F3EDE0" }}>Advance Registration</h2>
      <Field label="Ticket photo (required)">
        <input type="file" accept="image/*" onChange={handleFile} />
        {ticketStatus === "checking" && <div style={{ color: "#FFB020", fontSize: 12 }}>Reading ticket…</div>}
        {ticketStatus === "done" && <div style={{ color: "#3EE07A", fontSize: 12 }}>✓ Ticket verified</div>}
        {ticketStatus === "failed" && <div style={{ color: "#F43F5E", fontSize: 12 }}>Could not verify — try a clearer photo</div>}
      </Field>
      <CityVenuePicker city={form.city} venue={form.venue} onCity={(v) => setForm({ ...form, city: v })} onVenue={(v) => setForm({ ...form, venue: v })} />
      <Field label="Garba Date">
        <input type="date" style={inputStyle} min={new Date().toISOString().slice(0, 10)} value={form.eventDate} onChange={(e) => setForm({ ...form, eventDate: e.target.value })} />
      </Field>
      <Field label="Name"><input style={inputStyle} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
      <Field label="WhatsApp Number">
        <input style={inputStyle} value={form.whatsapp} onChange={(e) => setForm({ ...form, whatsapp: e.target.value.replace(/\D/g, "").slice(0, 10) })} placeholder="10-digit" />
      </Field>
      <OtpGate whatsapp={form.whatsapp} onVerified={setVerified} />
      <Field label="Garba Skill Level">
        <div style={{ display: "flex", gap: 8 }}>
          {LEVELS.map((l) => (
            <div key={l.id} onClick={() => setForm({ ...form, level: l.id })} style={{
              flex: 1, textAlign: "center", padding: 12, borderRadius: 10, cursor: "pointer",
              border: form.level === l.id ? `2px solid ${l.color}` : "1px solid #4A3B6E", color: "#F3EDE0",
            }}>
              <div>{l.icon}</div><div style={{ fontSize: 12 }}>{l.label}</div>
            </div>
          ))}
        </div>
      </Field>
      {error && <div style={{ color: "#F43F5E", marginBottom: 10 }}>{error}</div>}
      <button style={buttonStyle(!verified || !form.level || !ticketToken || !form.eventDate)} disabled={!verified || !form.level || !ticketToken || !form.eventDate} onClick={submit}>
        Pre-Book My Circle
      </button>
    </div>
  );
}

function FindCircle({ onExit }) {
  const [whatsapp, setWhatsapp] = useState("");
  const [results, setResults] = useState(null);

  async function lookup() {
    const res = await fetch(`/.netlify/functions/find?whatsapp=${whatsapp}`);
    const data = await res.json();
    setResults(res.ok ? data : []);
  }

  return (
    <div>
      <button style={{ ...ghostButtonStyle, marginBottom: 16 }} onClick={onExit}>← Exit</button>
      <h2 style={{ color: "#F3EDE0" }}>Find my Circle</h2>
      <Field label="WhatsApp number">
        <input style={inputStyle} value={whatsapp} onChange={(e) => setWhatsapp(e.target.value.replace(/\D/g, "").slice(0, 10))} />
      </Field>
      <button style={buttonStyle(whatsapp.length !== 10)} disabled={whatsapp.length !== 10} onClick={lookup}>Search</button>
      {results && results.length === 0 && <p style={{ color: "#8A81A8" }}>No registrations found.</p>}
      {results && results.map((r, i) => (
        <div key={i} style={cardStyle}>
          <div style={{ color: "#E3A542", fontSize: 11, fontWeight: 700 }}>{r.phase === "advance" ? "ADVANCE" : "LIVE"} · {r.registeredAt?.slice(0, 10)}</div>
          <div style={{ color: "#F3EDE0", fontSize: 18 }}>Circle #{r.circleId}</div>
          <div style={{ color: "#B9AFD1" }}>{r.landmark}, Zone {r.zone}</div>
        </div>
      ))}
    </div>
  );
}

function OrganizerDashboard({ onExit }) {
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");

  async function login() {
    setError("");
    const res = await fetch(`/.netlify/functions/organizer-stats?id=${encodeURIComponent(id)}&password=${encodeURIComponent(password)}`);
    const data = await res.json();
    if (!res.ok) { setError(data.error || "Login failed"); return; }
    setStats(data);
  }

  if (stats) {
    return (
      <div>
        <button style={{ ...ghostButtonStyle, marginBottom: 16 }} onClick={onExit}>← Exit</button>
        <h2 style={{ color: "#F3EDE0" }}>{stats.venue}</h2>
        <p style={{ color: "#8A81A8" }}>{stats.city} · Aggregate stats only</p>
        <div style={cardStyle}>
          <div style={{ color: "#F3EDE0" }}>Total registrations: {stats.totalRegistrations}</div>
          <div style={{ color: "#F3EDE0" }}>Advance: {stats.advanceCount} · Live: {stats.liveCount}</div>
          <div style={{ color: "#F3EDE0" }}>Circles formed: {stats.circlesFormed} (avg {stats.avgCircleSize})</div>
          <div style={{ color: "#F3EDE0" }}>All-women circles: {stats.allWomenCircles} (avg {stats.avgAllWomenCircleSize})</div>
          <div style={{ color: "#F3EDE0" }}>Show-up rate: {stats.showUpRatePercent !== null ? stats.showUpRatePercent + "%" : "No data yet"}</div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <button style={{ ...ghostButtonStyle, marginBottom: 16 }} onClick={onExit}>← Exit</button>
      <h2 style={{ color: "#F3EDE0" }}>Organizer Dashboard</h2>
      <Field label="Venue ID"><input style={inputStyle} value={id} onChange={(e) => setId(e.target.value)} placeholder="e.g. AH-GMDC" /></Field>
      <Field label="Password"><input type="password" style={inputStyle} value={password} onChange={(e) => setPassword(e.target.value)} /></Field>
      {error && <div style={{ color: "#F43F5E", marginBottom: 10 }}>{error}</div>}
      <button style={buttonStyle(false)} onClick={login}>View Dashboard</button>
    </div>
  );
}

export default function App() {
  const [view, setView] = useState("home");

  return (
    <div style={{ minHeight: "100vh", background: "#14101F", fontFamily: "sans-serif", padding: "20px 16px", maxWidth: 480, margin: "0 auto" }}>
      {view === "home" && (
        <div>
          <h1 style={{ color: "#F3EDE0" }}>{BRAND}</h1>
          <p style={{ color: "#8A81A8", marginBottom: 20 }}>Functional core build — see README for what's ported vs. what still needs finishing.</p>
          <button style={{ ...buttonStyle(false), marginBottom: 10 }} onClick={() => setView("live")}>Find Solo Garba Circle (Live)</button>
          <button style={{ ...buttonStyle(false), marginBottom: 10 }} onClick={() => setView("advance")}>Pre-Book My Circle (Advance)</button>
          <button style={{ ...ghostButtonStyle, width: "100%", boxSizing: "border-box", marginBottom: 10 }} onClick={() => setView("find")}>Find my Circle</button>
          <button style={{ ...ghostButtonStyle, width: "100%", boxSizing: "border-box" }} onClick={() => setView("organizer")}>Organizer Dashboard</button>
        </div>
      )}
      {view === "live" && <LiveRegister onExit={() => setView("home")} />}
      {view === "advance" && <AdvanceRegister onExit={() => setView("home")} />}
      {view === "find" && <FindCircle onExit={() => setView("home")} />}
      {view === "organizer" && <OrganizerDashboard onExit={() => setView("home")} />}
    </div>
  );
}
